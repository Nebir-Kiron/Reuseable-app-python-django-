version = "2.4.7"
default_app_config = "dismin.apps.DisminConfig"
