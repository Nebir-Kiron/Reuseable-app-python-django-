
from django.apps import AppConfig


class DisminConfig(AppConfig):
    name = 'dismin'
    



